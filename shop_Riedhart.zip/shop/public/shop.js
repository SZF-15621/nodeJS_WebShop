document.addEventListener('DOMContentLoaded', () => {
    fetch('/api/products')
        .then(response => response.json())
        .then(products => {
            let productHTML = '';
            products.forEach(product => {
                productHTML += `
                    <div class="product">
                        <h2>${product.name}</h2>
                        <p>${product.description}</p>
                        <img src="${product.image}">
                        <p>Price: €${product.price}</p>
                        <button onclick="addToCart(${product.id})">Add to Cart</button>
                    </div>`;
            });
            document.getElementById('products').innerHTML = productHTML;
        });

    updateCart();
});

function addToCart(productId) {
    let cart = JSON.parse(localStorage.getItem('cart')) || [];
    cart.push(productId);
    localStorage.setItem('cart', JSON.stringify(cart));
    updateCart();
}
function removeFromCart(productId) {
    let cart = JSON.parse(localStorage.getItem('cart')) || []; // Korrektur hier
    cart = cart.filter(id => id !== productId);
    localStorage.setItem('cart', JSON.stringify(cart));
    updateCart();
}


function updateCart() {
    let cart = JSON.parse(localStorage.getItem('cart')) || [];
    let cartItemsHTML = '';

    fetch('/api/products')
        .then(response => response.json())
        .then(products => {
            cart.forEach(productId => {
                const product = products.find(p => p.id === productId);
                cartItemsHTML += `
                    <p>
                        ${product.name} - €${product.price}
                        <button onclick="removeFromCart(${productId})">Remove</button>
                    </p>`;
            });
            document.getElementById('cart-items').innerHTML = cartItemsHTML;
        });
}

function checkout() {
    document.getElementById('checkoutForm').style.display = 'block';
}

document.getElementById('checkoutForm').addEventListener('submit', function(e) {
    e.preventDefault();

    let cart = JSON.parse(localStorage.getItem('cart')) || [];
    let formData = new FormData(this);
    let order = {
        customer: {
            name: formData.get('name'),
            address: formData.get('address'),
            email: formData.get('email')
        },
        items: cart
    };

    fetch('/api/orders', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(order)
    })
    .then(response => response.json())
    .then(data => {
        console.log('Order placed:', data);
        localStorage.removeItem('cart');
        updateCart();
        alert('Order placed successfully!');
        document.getElementById('checkoutForm').reset();
        document.getElementById('checkoutForm').style.display = 'none';
    });
});
