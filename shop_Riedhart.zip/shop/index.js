const express = require('express');
const fs = require('fs');
const path = require('path');
const app = express();

app.use(express.json());
app.use(express.static('public'));

// API-Endpunkt zum Abrufen der Produktdaten
app.get('/api/products', (req, res) => {
    const products = JSON.parse(fs.readFileSync(path.join(__dirname, 'data/products.json')));
    res.json(products);
});

// API-Endpunkt zum Speichern von Bestellungen
app.post('/api/orders', (req, res) => {
    const orders = JSON.parse(fs.readFileSync(path.join(__dirname, 'data/orders.json')));
    const newOrder = {
        id: orders.length + 1,
        ...req.body,
        timestamp: new Date().toISOString()
    };
    orders.push(newOrder);
    fs.writeFileSync(path.join(__dirname, 'data/orders.json'), JSON.stringify(orders, null, 2));
    res.status(201).json(newOrder);
});

// Server starten
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
